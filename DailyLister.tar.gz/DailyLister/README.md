EasyLister - A Todo App to manage your activities

Features
- Add new items and save to localStorage
- Inline editing
- Delete items
- Delete items from localStorage
